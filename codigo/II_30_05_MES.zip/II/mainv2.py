# -*- coding: utf-8 -*-
from getOrder import *
from basedados import *
from client import *
import time


def main():
    
    #------INICIALIZACAO--------
    reinicia_armazem()
    reinicia_maquina()
    #receber_ordem()
    
    #------- i E O ID DA ORDEM A PROCESSAR-------
    i = 1
    
  
    
    tamanho = nr_ordens_pendentes()
    while tamanho == 0:
        tamanho = nr_ordens_pendentes()
      
      
    while True:
            
        tamanho = nr_ordens_pendentes()
        while i < tamanho + 1:
              
            id_ordem, tipo=ordenar_tabela()
              
            if tipo == 'Transform':
                set_valor_uint_2("order", 1) 
                   
                id_processo = seleciona_processo(pedidos_pendentes_pi(id_ordem), pedidos_pendentes_pf(id_ordem))
                       
                    
                while pecas_pendentes_quantidade(id_ordem) > 0:
                       
                    if (seleciona_inventario(pedidos_pendentes_pi(id_ordem)) > 1):    
                           
                           
                        if ordem_por_iniciar(id_ordem) == True:
                            ordem_a_processar(id_ordem)
                            hora_inicio_ordem(id_ordem)
                                          
                        if get_valor("sAT1") == False and get_valor("sC1T1") == False:    
                            enviar_dados(id_processo, id_ordem)
                            entrar_armazem()
                            entrar_pusher(tamanho)    
                                                      
                            time.sleep(2)
                            set_valor_uint("ID_PECA_WO.peca_i", 0)
                           
                        tamanho = nr_ordens_pendentes()     
                        entrar_armazem()
                        entrar_pusher(tamanho)
                        peca_processada(tamanho)
                        atualizar_stats_maq()
                           
                            
    
                    else:
                        ordem_suspenso(id_ordem)
                        break
    
                    entrar_armazem()
                    peca_processada(tamanho)
                    atualizar_stats_maq()
                        
                       
            if tipo == 'Unload':
                set_valor_uint_2("order", 2) 
                    
                while pecas_pendentes_quantidade(id_ordem) > 0:
                    if (seleciona_inventario(pedidos_pendentes_pi(id_ordem)) > 1):          
                        if ordem_por_iniciar(id_ordem) == True:
                            ordem_a_processar(id_ordem)
                            hora_inicio_ordem(id_ordem)
                                          
                        if get_valor("sAT1") == False and get_valor("sC1T1") == False:    
                            enviar_dados_unload(id_ordem)
                            entrar_pusher(tamanho)
                            entrar_armazem()
                            time.sleep(2)
                            set_valor_uint("ID_PECA_WO.peca_i", 0)
                           
                           
                        tamanho = nr_ordens_pendentes()
                        entrar_pusher(tamanho)
                        peca_processada(tamanho)
                        entrar_armazem()
                        atualizar_stats_maq()
                           
                    else:
                        ordem_suspenso(id_ordem)
                        break
       
            entrar_armazem()
            entrar_pusher(tamanho)
            peca_processada(tamanho)
            atualizar_stats_maq()
                
            i = i + 1
           
        entrar_pusher(tamanho)    
        entrar_armazem()
        peca_processada(tamanho)
        atualizar_stats_maq()
    
   
def entrar_armazem():
    if get_valor("sAT2") == True :
        order_id = get_valor("AT2.lista_atual.order_id")
        if order_id != 0:
            entrada_peca(pedidos_pendentes_pf(order_id))
            set_valor_bool("ID_PECA_WI.peca_f", True)
        if order_id == 0:    
            if get_valor("AT2.lista_atual.peca_carga") == 1:
                entrada_peca("P1")
                set_valor_bool("ID_PECA_WI.peca_f", True)
            if get_valor("AT2.lista_atual.peca_carga") == 2:
                entrada_peca("P2") 
                set_valor_bool("ID_PECA_WI.peca_f", True)
           
               
        time.sleep(1)
       
        set_valor_bool("ID_PECA_WI.peca_f", False)
           
   
   
   
def entrar_pusher(tamanho):
    for i in range(1,tamanho+1):
        string1 = "C7T3.pecas_por_ordem_maquina.pecas_por_ordem_geral[" + str(i) + "]"
        string2 = "C7T4.pecas_por_ordem_maquina.pecas_por_ordem_geral[" + str(i) + "]"
        string3 = "C7T5.pecas_por_ordem_maquina.pecas_por_ordem_geral[" + str(i) + "]"
        result =  get_valor(string1) + get_valor(string2) + get_valor(string3)
           
        if result > 0:
            atualizar_pecas_processadas(i, result)
            em_processo = quantidade_desejada(i) - result
               
            atualizar_pecas_em_processamento_fim(i, em_processo)
            if result == quantidade_desejada(i) and buscar_hora_fim(i) == ' ':
                ordem_processada(i)
                hora_fim_ordem(i)    
  
def atualizar_stats_maq():
    for i in range(1, 10):
        aux = 0
        for j in range(1, 10):
            if i == 1:
                string = "C1T3.p_transf.P" + str(j)
            if i == 2:
                string = "C1T4.p_transf.P" + str(j)
            if i == 3:
                string = "C1T5.p_transf.P" + str(j)
            if i == 4:
                string = "C3T3.p_transf.P" + str(j)
            if i == 5:
                string = "C3T4.p_transf.P" + str(j)
            if i == 6:
                string = "C3T5.p_transf.P" + str(j)
            if i == 7:
                string = "C5T3.p_transf.P" + str(j)
            if i == 8:
                string = "C5T4.p_transf.P" + str(j)
            if i == 9:
                string = "C5T5.p_transf.P" + str(j)
                
            result = get_valor(string)
            aux += result
            
            atualizar_stats_maquina_db(j, i, result, aux)
    
    
def peca_processada(tamanho):
    for i in range(1,tamanho+1):
        string1 = "C1T3.pecas_por_ordem_maquina.pecas_por_ordem_geral[" + str(i) + "]"
        string2 = "C1T4.pecas_por_ordem_maquina.pecas_por_ordem_geral[" + str(i) + "]"
        string3 = "C1T5.pecas_por_ordem_maquina.pecas_por_ordem_geral[" + str(i) + "]"
        string4 = "C3T3.pecas_por_ordem_maquina.pecas_por_ordem_geral[" + str(i) + "]"
        string5 = "C3T4.pecas_por_ordem_maquina.pecas_por_ordem_geral[" + str(i) + "]"
        string6 = "C3T5.pecas_por_ordem_maquina.pecas_por_ordem_geral[" + str(i) + "]"
        string7 = "C5T3.pecas_por_ordem_maquina.pecas_por_ordem_geral[" + str(i) + "]"
        string8 = "C5T4.pecas_por_ordem_maquina.pecas_por_ordem_geral[" + str(i) + "]"
        string9 = "C5T5.pecas_por_ordem_maquina.pecas_por_ordem_geral[" + str(i) + "]"
        result = get_valor(string1) + get_valor(string2) + get_valor(string3) + get_valor(string4) + get_valor(string5)+get_valor(string6)+get_valor(string7)+get_valor(string8)+get_valor(string9)
           
        if result > 0:
            atualizar_pecas_processadas(i, result)
            em_processo = quantidade_desejada(i) - result
            atualizar_pecas_em_processamento_fim(i, em_processo)
            if result == quantidade_desejada(i) and buscar_hora_fim(i) == ' ':
                ordem_processada(i)
                hora_fim_ordem(i)
       
   
def enviar_dados_unload(i):
    set_valor_uint_2("order_id", i)
    set_valor_uint("ID_PECA_WO.peca_i", separar_P(pedidos_pendentes_pi(i)))
       
    pusher=get_pusher(i)
    set_valor_uint_2("pusher_destino", pusher)
    #---Atualizar base de dados----
    saida_peca(pedidos_pendentes_pi(i))
    atualizar_pecas_pendentes(i)
    atualizar_pecas_em_processamento(i)
       
       
def enviar_dados(id_processo, i):
    set_valor_uint_2("order_id", i)
       
    f = [int(ferramenta1(id_processo)),int(ferramenta2(id_processo)),int(ferramenta3(id_processo)),int(ferramenta4(id_processo)),int(ferramenta5(id_processo))]
    set_valor_uint_2("ferramenta", f)
                                        
    m = [int_maquina(maquina1(id_processo)), int_maquina(maquina2(id_processo)), int_maquina(maquina3(id_processo)), int_maquina(maquina4(id_processo)), int_maquina(maquina5(id_processo))] 
    set_valor_uint_2("maquina",m)
   
                                         
                                         
    t = [int(tempo1(id_processo)),int(tempo2(id_processo)),int(tempo3(id_processo)),int(tempo4(id_processo)),int(tempo5(id_processo))]
    set_valor_int_64("tempo",t)
      
      
    seq3 = []
    seq=seq_pecas(id_processo)
    seq2 = seq.replace(",", ' ', len(seq))
    for k in range(0,len(seq)):
        if seq2[k] != ' ':
            seq3.append(int(seq2[k]))
    
    if len(seq3) <6:        
        for j in range(len(seq3)+1,7):
            seq3.append(0)
            j=j
    
    set_valor_uint_2("sequencia_pecas", seq3)
                                         
    set_valor_uint("ID_PECA_WO.peca_i", separar_P(pedidos_pendentes_pi(i)))
       
    #---Atualizar base de dados----
    saida_peca(pedidos_pendentes_pi(i))
    atualizar_pecas_pendentes(i)
    atualizar_pecas_em_processamento(i)

   
def separar_P(peca):
    return int(peca.split('P')[1])
   
   
def int_maquina(maquina):
    if maquina == 'Ma':
        return 1
    if maquina == 'Mb':
        return 2
    if maquina == 'Mc':
        return 3
    return 0
 
main()