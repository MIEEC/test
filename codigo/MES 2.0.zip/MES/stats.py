from client import * 
from basedados import *



while True:
    i=0
    for i in range(1, 10):
        aux = 0
        for j in range(1, 10):
            if i == 1:
                string = "C1T3.p_transf.P" + str(j)
                string2 = "C1T3.tempo_maquinacao_total"
            if i == 2:
                string = "C1T4.p_transf.P" + str(j)
                string2 = "C1T4.tempo_maquinacao_total"
            if i == 3:
                string = "C1T5.p_transf.P" + str(j)
                string2 = "C1T5.tempo_maquinacao_total"
            if i == 4:
                string = "C3T3.p_transf.P" + str(j)
                string2 = "C3T3.tempo_maquinacao_total"
            if i == 5:
                string = "C3T4.p_transf.P" + str(j)
                string2 = "C3T4.tempo_maquinacao_total"
            if i == 6:
                string = "C3T5.p_transf.P" + str(j)
                string2 = "C3T5.tempo_maquinacao_total"
            if i == 7:
                string = "C5T3.p_transf.P" + str(j)
                string2 = "C5T3.tempo_maquinacao_total"
            if i == 8:
                string = "C5T4.p_transf.P" + str(j)
                string2 = "C5T4.tempo_maquinacao_total"
                
            if i == 9:
                string = "C5T5.p_transf.P" + str(j)
                string2 = "C5T5.tempo_maquinacao_total"
                  
            result = get_valor(string)
            aux += result
            
            if j==1:
                time = get_valor(string2) / 1000
                
            atualizar_stats_maquina_db(j, i, result, aux, time)
    
    tamanho = nr_ordens_pendentes()
    for l in range(1, tamanho +1):       
        atualizar_folga(l)
        



