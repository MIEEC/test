from getOrder import *
from basedados import *
from client import *
import time


def main():
        
    #------INICIALIZAÇÃO--------
    reinicia_armazem()
    receber_ordem()
    
  
     
    while True:
        tamanho = nr_ordens_pendentes()
         
        for i in range(1,tamanho):
            if pedidos_pendentes_tipo(i) == 'Transform':
                 
                #-------SLECIONAR PROCESSO CONSOANTE PI E PF--------
                id_processo = seleciona_processo(pedidos_pendentes_pi(i), pedidos_pendentes_pf(i))
                 
                while pecas_pendentes_quantidade(i) > 0:
                     
                    #--------PRCESSAR PEDIDO---------
                    if (seleciona_inventario(pedidos_pendentes_pi(i)) > 1):
                        if ordem_por_iniciar(i) == 'True':
                            ordem_a_processar(i)
                            hora_inicio_ordem(i)
                            
                        if get_valor("sAT1") == False:
                             
                            #-----ENVIAR INFO DO PROCESSO PARA O PLC-----    
                            f = [int(ferramenta(id_processo)),1,0,0,0]
                            set_valor_uint_2("ferramenta", f)
                            
                            m = [int(int_maquina(id_processo)),0,0,0,0] 
                            set_valor_uint_2("maquina",m)
                            
                            t = [int(tempo(id_processo)),0,0,0,0]
                            set_valor_int_64("tempo",t)
                            
                            set_valor_uint("peca_i", separar_P(pedidos_pendentes_pi(i)))
                               
                            #------ATUALIZAR BASE DE DADOS-------
                            saida_peca(pedidos_pendentes_pi(i))
                            atualizar_pecas_pendentes(i)
                            atualizar_pecas_em_processamento(i)
                               
                            #------VERIFICAR SE HÁ NOVAS ORDENS-----
                            tamanho = nr_ordens_pendentes()
                                
                            time.sleep(3)
                            set_valor_uint("peca_i", 0)
                              
                        #------VERIFICAR PEÇA PROCESSADA | WAREHOUSE_IN: VARIAVEL QUE DETETA ENTRADA NO ARMAZEM------------
#                         if get_valor("warehouse_in") == 'True':
#                             atualizar_pecas_processadas(i)
#                             #-----NESTE MOMENTO A PECA É CONSIDERADA PROCESSADA QUANDO ENTRA NO ARMAZEM---- A ALTERAR!
#                             entrada_peca(pedidos_pendentes_pf(i))
                            
                    else:
                        ordem_suspenso(i)
                        break
        
                hora_fim_ordem(i)


    
def separar_P(peca):
    return int(peca.split('P')[1])

def int_maquina(id_processo):
    if maquina(id_processo) == 'Ma':
        return 1
    if maquina(id_processo) == 'Mb':
        return 2
    if maquina(id_processo) == 'Mc':
        return 3

main()