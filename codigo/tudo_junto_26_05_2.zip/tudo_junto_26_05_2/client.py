from opcua import Client
from opcua import ua
#import time
 
class conection():
     
    url = "opc.tcp://DUARTE-PC:4840"
    client = Client(url)
    client.connect()
 
     
 
def get_valor(string):
    local = "ns=4;s=|var|CODESYS Control Win V3 x64.Application.PLC_PRG." + string
    get_var = conection.client.get_node(local)
    return get_var.get_value()
 
 
def set_valor_bool(string, valor):
    local = "ns=4;s=|var|CODESYS Control Win V3 x64.Application." + string
    set_var = conection.client.get_node(local)
    set_var.set_value(ua.Variant(valor, ua.VariantType.Boolean))
     
     
def set_valor_uint(string, valor): 
    local = "ns=4;s=|var|CODESYS Control Win V3 x64.Application." + string
    set_var = conection.client.get_node(local)
    set_var.set_value(ua.Variant(valor, ua.VariantType.UInt16))
 
def set_valor_str(string, valor): 
    local = "ns=4;s=|var|CODESYS Control Win V3 x64.Application.ID_PECA." + string
    set_var = conection.client.get_node(local)
    set_var.set_value(ua.Variant(valor, ua.VariantType.String))
     
def set_valor_uint_2(string, valor): 
    local = "ns=4;s=|var|CODESYS Control Win V3 x64.Application.tentativa_string.lista_atual." + string
    set_var = conection.client.get_node(local)
    set_var.set_value(ua.Variant(valor, ua.VariantType.UInt16))
     
def set_valor_int_64(string, valor): 
    local = "ns=4;s=|var|CODESYS Control Win V3 x64.Application.tentativa_string.lista_atual." + string
    set_var = conection.client.get_node(local)
    set_var.set_value(ua.Variant(valor, ua.VariantType.Int64))    
    
    
def get_valor_2(string):
    local = "ns=4;s=|var|CODESYS Control Win V3 x64.Application." + string
    get_var = conection.client.get_node(local)
    return get_var.get_value()

     