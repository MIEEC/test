# -*- coding: utf-8 -*-
from getOrder import *
from basedados import *
from client import *
import time

def main():
    
    #------INICIALIZACAO--------
    reinicia_armazem()
    #receber_ordem()
    
    #------- i E O ID DA ORDEM A PROCESSAR-------
    i = 1
    

    while True:
         
        tamanho = nr_ordens_pendentes()
        while i < tamanho + 1:
            if pedidos_pendentes_tipo(i) == 'Transform':
                set_valor_uint_2("order", 1) 
                id_processo = seleciona_processo(pedidos_pendentes_pi(i), pedidos_pendentes_pf(i))
                 
                while pecas_pendentes_quantidade(i) > 0:
                    if (seleciona_inventario(pedidos_pendentes_pi(i)) > 1):          
                        if ordem_por_iniciar(i) == True:
                            ordem_a_processar(i)
                            hora_inicio_ordem(i)
                                       
                        if get_valor("sAT1") == False and get_valor("sC2T1") == False:    
                            enviar_dados(id_processo, i)
                             
                            time.sleep(1)
                            set_valor_uint("ID_PECA_WO.peca_i", 0)
                             
                        entrar_armazem()
 
                    else:
                        ordem_suspenso(i)
                        break
 
                    entrar_armazem()
                  
            if pedidos_pendentes_tipo(i) == 'Unload':
                set_valor_uint_2("order", 2) 
                 
                while pecas_pendentes_quantidade(i) > 0:
                    if (seleciona_inventario(pedidos_pendentes_pi(i)) > 1):          
                        if ordem_por_iniciar(i) == True:
                            ordem_a_processar(i)
                            hora_inicio_ordem(i)
                                       
                        if get_valor("sAT1") == False and get_valor("sC2T1") == False:    
                            enviar_dados_unload(i)
                             
                            time.sleep(1)
                            set_valor_uint("ID_PECA_WO.peca_i", 0)
 
                    else:
                        ordem_suspenso(i)
                        break
    
            entrar_armazem()
            i = i + 1


def entrar_armazem():
    if get_valor("sAT2") == True:
        order_id = get_valor_2("PLC_PRG.AT2.lista_atual.order_id")
        entrada_peca(pedidos_pendentes_pf(int(order_id)))
        
        set_valor_bool("ID_PECA_WI.peca_f", True)  
        time.sleep(0.5)
    else:
        set_valor_bool("ID_PECA_WI.peca_f", False)

# 
# def fim_ordem():
#     order_id = get_valor_2("order_id")
#     if nr_pecas_processadas(order_id) == quantidade_desejada(order_id):
#         hora_fim_ordem(order_id)
#         ordem_processada(order_id)
        

def enviar_dados_unload(i):
    set_valor_uint_2("order_id", i)
    set_valor_uint("ID_PECA_WO.peca_i", separar_P(pedidos_pendentes_pi(i)))
    
    pusher=get_pusher(i)
    set_valor_uint_2("pusher_destino", pusher)
    #---Atualizar base de dados----
    saida_peca(pedidos_pendentes_pi(i))
    atualizar_pecas_pendentes(i)
    atualizar_pecas_em_processamento(i)
    
    
def enviar_dados(id_processo, i):
    set_valor_uint_2("order_id", i)
    
    f = [int(ferramenta1(id_processo)),int(ferramenta2(id_processo)),int(ferramenta3(id_processo)),int(ferramenta4(id_processo)),int(ferramenta5(id_processo))]
    set_valor_uint_2("ferramenta", f)
                                     
    m = [int_maquina(maquina1(id_processo)), int_maquina(maquina2(id_processo)), int_maquina(maquina3(id_processo)), int_maquina(maquina4(id_processo)), int_maquina(maquina5(id_processo))] 
    set_valor_uint_2("maquina",m)
                                      
                                      
    t = [int(tempo1(id_processo)),int(tempo2(id_processo)),int(tempo3(id_processo)),int(tempo4(id_processo)),int(tempo5(id_processo))]
    set_valor_int_64("tempo",t)
                                      
    set_valor_uint("ID_PECA_WO.peca_i", separar_P(pedidos_pendentes_pi(i)))
    
    #---Atualizar base de dados----
    saida_peca(pedidos_pendentes_pi(i))
    atualizar_pecas_pendentes(i)
    atualizar_pecas_em_processamento(i)


def separar_P(peca):
    return int(peca.split('P')[1])


def int_maquina(maquina):
    if maquina == 'Ma':
        return 1
    if maquina == 'Mb':
        return 2
    if maquina == 'Mc':
        return 3
    return 0

main()