import psycopg2
import functools 
from datetime import datetime

class Base_Dados():
    
    connection= psycopg2.connect(host="db.fe.up.pt", database="up201603858", user="up201603858", password="onr482mNS", port="5432")

    connection.autocommit= True
    cursor = connection.cursor()
    
    connection.commit()
    
    uid=1

#Insere uma ordem na basedados 
def basedados_inserir_ordem(numero_de_ordem, tipo_de_ordem, quantidade, peca_inicial, peca_final, destino, hora_entrada_ordem,hora_inicio_ordem, hora_fim_ordem):
    
    #na tabela de Ordens
    sql_insert_query = ("""INSERT INTO "Ordens" ("ID","Tipo","estado","pecas_processadas","pecas_em_processamento","pecas_pendentes","peca_inicial", "peca_final", "Destino", "hora_entrada_ordem", "hora_inicio_ordem", "hora_fim_ordem") VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s, %s, %s)""")
    insert_tuple = (numero_de_ordem , tipo_de_ordem, 'pendente','0', '0', quantidade, peca_inicial, peca_final, destino, hora_entrada_ordem, hora_inicio_ordem, hora_fim_ordem)
    Base_Dados.cursor.execute(sql_insert_query, insert_tuple)

    #na tabela de pedidos_pendentes
    sql_insert_query2 = ("""INSERT INTO "pedidos_pendentes" ("id", "order_id","peca_inicial", "peca_final", "quantidade_desejada", "destino", "tipo", "hora_entrada_ordem") VALUES (%s,%s,%s,%s,%s,%s,%s, %s)""")
    Base_Dados.cursor.execute("SELECT COUNT (*) FROM pedidos_pendentes")  #conta o numero de linhas da tabela
    n_pedidos_pendentes = 1+Base_Dados.cursor.fetchone()[0]
    insert_tuple2 =(n_pedidos_pendentes, numero_de_ordem, peca_inicial, peca_final, quantidade, destino, tipo_de_ordem, hora_entrada_ordem )
    Base_Dados.cursor.execute(sql_insert_query2, insert_tuple2)

    return

def reinicia_armazem():
    
    sql_insert_query = ("""Update "Inventario" set "P1" = 54 , "P2" = 54, "P3"=54, "P4"=54, "P5"=54, "P6"=54, "P7"=54, "P8"=54, "P9"=54  where "id" = 1""")
    
    Base_Dados.cursor.execute(sql_insert_query)

    return 

def pedidos_pendentes_tipo(i):
    
    PostgreSQL_select_Query = "select tipo from pedidos_pendentes WHERE id=" + str(i)
    Base_Dados.cursor.execute(PostgreSQL_select_Query)
    Proxima_ordem_tipo = Base_Dados.cursor.fetchone()
    Proxima_ordem_tipo =  ''.join(Proxima_ordem_tipo) #a fun��o retorna um TUPLE. Com ''.join() � tranformado em STRING
    return Proxima_ordem_tipo


def pedidos_pendentes_quatidade(i):
    PostgreSQL_select_Query = "select quantidade_desejada from pedidos_pendentes WHERE id=" + str(i)
    Base_Dados.cursor.execute(PostgreSQL_select_Query)
    Proxima_ordem_quantidade = Base_Dados.cursor.fetchone()
    Proxima_ordem_quantidade = functools.reduce(lambda sub, ele: sub * 10 + ele, Proxima_ordem_quantidade) 
    return Proxima_ordem_quantidade


def pedidos_pendentes_pi(i):
    PostgreSQL_select_Query = "select peca_inicial from pedidos_pendentes WHERE id=" + str(i)
    Base_Dados.cursor.execute(PostgreSQL_select_Query)
    Proxima_ordem_pi = Base_Dados.cursor.fetchone()
    Proxima_ordem_pi =  ''.join(Proxima_ordem_pi)
    return Proxima_ordem_pi


def pedidos_pendentes_pf(i):
    PostgreSQL_select_Query = "select peca_final from pedidos_pendentes WHERE id=" + str(i)
    Base_Dados.cursor.execute(PostgreSQL_select_Query)
    Proxima_ordem_pf = Base_Dados.cursor.fetchone()
    Proxima_ordem_pf =  ''.join(Proxima_ordem_pf)
    return Proxima_ordem_pf
    
    
def apagar_ordem_executada():
    deleteStatement = "DELETE FROM pedidos_pendentes WHERE id= (SELECT id FROM pedidos_pendentes order by id limit 1)"
    Base_Dados.cursor.execute(deleteStatement)
    
    
def nr_ordens_pendentes():
    query = "SELECT COUNT (*) FROM pedidos_pendentes"
    Base_Dados.cursor.execute(query)
    result = Base_Dados.cursor.fetchone()
    return result[0]
 
    
def seleciona_processo(pi, pf):
    query = "SELECT id from processos WHERE pi=" + pi + " AND pf=" + pf
    Base_Dados.cursor.execute(query)
    result = Base_Dados.cursor.fetchone()
    return result


def seleciona_inventario(pi):
    query = "SELECT " + pi + " FROM Inventario WHERE id=1"
    Base_Dados.cursor.execute(query)
    result = Base_Dados.cursor.fetchone()
    result = functools.reduce(lambda sub, ele: sub * 10 + ele, result) 
    return result


def ordem_a_processar(i):
    query = "UPDATE ordens SET estado = 'A Processar' WHERE id =" + str(i)
    Base_Dados.cursor.execute(query)
    

def hora_inicio_ordem(i):
    now = datetime.now()
    current_time = now.strftime("%H:%M:%S")
    
    query = "UPDATE ordens SET hora_inicio_ordem = " + current_time + "WHERE id =" + str(i)
    Base_Dados.cursor.execute(query)
    