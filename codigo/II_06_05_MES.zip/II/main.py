from getOrder import *
from basedados import *
from client import*


def main():
        
    #inicializacao
    reinicia_armazem()
       
    
    while True:
        tamanho = nr_ordens_pendentes()
        for i in range(1,tamanho):
            tamanho = tamanho - 1
            if pedidos_pendentes_tipo(i) == 'Transform':
                #selecionar processo consoante pi e pf
                while pedidos_pendentes_quatidade(i) > 0:
                    #processar pedido
                    if (seleciona_inventario(pedidos_pendentes_pi(i)) > 1):
                        ordem_a_processar(i)
                        
                        set_valor_int("ATw1", separar_P(pedidos_pendentes_pi(i)))
                        
    
    

def separar_P(peca):
    return int(peca.split('P')[1])