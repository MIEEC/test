from getOrder import *
from basedados import *
from client import *
import time


def main():
        
    #------INICIALIZACAO--------
    reinicia_armazem()
    #receber_ordem()
    #------- i E O ID DA ORDEM A PROCESSAR-------
    i = 1
    
    
    while True:
          
        tamanho = nr_ordens_pendentes()
        #------O CICLO WHILE PERMITE MANTER O I AO CONTRARIO DO CICLO FOR QUE COLOCA I=0 ASSIM QUE AS ORDEM PENDENTES ACABAREM TEMPORARIAMENTE----- 
        while i < tamanho:
            #print(i)
            if pedidos_pendentes_tipo(i) == 'Transform':
                set_valor_uint_2("order", 1) 
                #-------SLECIONAR PROCESSO CONSOANTE PI E PF--------
                id_processo = seleciona_processo(pedidos_pendentes_pi(i), pedidos_pendentes_pf(i))
                    
                while nr_pecas_processadas(i) < quantidade_desejada(i):
                    while pecas_pendentes_quantidade(i) > 0:
                              
                        #--------PRCESSAR PEDIDO---------
                        if (seleciona_inventario(pedidos_pendentes_pi(i)) > 1):
                                
                            if ordem_por_iniciar(i) == True:
                                ordem_a_processar(i)
                                hora_inicio_ordem(i)
                                     
                            if get_valor("sAT1") == False and get_valor("sC2T1") == False:
                                      
                                #-----ENVIAR INFO DO PROCESSO PARA O PLC-----    
                                f = [int(ferramenta1(id_processo)),int(ferramenta2(id_processo)),int(ferramenta3(id_processo)),int(ferramenta4(id_processo)),int(ferramenta5(id_processo))]
                                set_valor_uint_2("ferramenta", f)
                                    
                                m = [int_maquina(maquina1(id_processo)), int_maquina(maquina2(id_processo)), int_maquina(maquina3(id_processo)), int_maquina(maquina4(id_processo)), int_maquina(maquina5(id_processo))] 
                                set_valor_uint_2("maquina",m)
                                     
                                     
                                t = [int(tempo1(id_processo)),int(tempo2(id_processo)),int(tempo3(id_processo)),int(tempo4(id_processo)),int(tempo5(id_processo))]
                                set_valor_int_64("tempo",t)
                                     
                                set_valor_uint("ID_PECA_WO.peca_i", separar_P(pedidos_pendentes_pi(i)))
                                        
                                #------ATUALIZAR BASE DE DADOS-------
                                saida_peca(pedidos_pendentes_pi(i))
                                atualizar_pecas_pendentes(i)
                                atualizar_pecas_em_processamento(i)
                                        
                                #------VERIFICAR SE HA NOVAS ORDENS-----
                                tamanho = nr_ordens_pendentes()
                                         
                                time.sleep(3)
                                set_valor_uint("ID_PECA_WO.peca_i", 0)
                                       
                            #------VERIFICAR PECA PROCESSADA | WAREHOUSE_IN: VARIAVEL QUE DETETA ENTRADA NO ARMAZEM------------
                            if get_valor("sAT2") == True:
                                    
                                set_valor_bool("ID_PECA_WI.peca_f", True)
                                atualizar_pecas_processadas(i)
                                atualizar_pecas_em_processamento_fim(i)
                                #-----NESTE MOMENTO A PECA ESTA CONSIDERADA PROCESSADA QUANDO ENTRA NO ARMAZEM---- A ALTERAR!
                                entrada_peca(pedidos_pendentes_pf(i))
                                    
                            #----ESTE DELAY PERMITE A ENTRADA CORRETA DE PECAS NO ARMAZEM---  
                            time.sleep(1)
                            set_valor_bool("ID_PECA_WI.peca_f", False)
                        else:
                            ordem_suspenso(i)
                            break
                            
                    #------VERIFICAR PECA PROCESSADA | WAREHOUSE_IN: VARIAVEL QUE DETETA ENTRADA NO ARMAZEM------------
                    set_valor_bool("ID_PECA_WI.peca_f", False)
                        
                    #----- DEPOIS DE COLOCAR AS PECAS NA FABRICA, NECESSITA AINDA DE AS COLOCAR NO ARMAZEM-----
                        
                    time.sleep(1)
                    if get_valor("sAT2") == True:
                            
                        set_valor_bool("ID_PECA_WI.peca_f", True)
                        atualizar_pecas_processadas(i)
                        atualizar_pecas_em_processamento_fim(i)
                        #-----NESTE MOMENTO A PECA ESTA CONSIDERADA PROCESSADA QUANDO ENTRA NO ARMAZEM---- A ALTERAR!
                        entrada_peca(pedidos_pendentes_pf(i)) 
                            
                            
                      
                             
                hora_fim_ordem(i)
                ordem_processada(i)
              
              
            if pedidos_pendentes_tipo(i) == 'Unload':   
                set_valor_uint_2("order", 2)
                while nr_pecas_processadas(i) < quantidade_desejada(i):
                    while pecas_pendentes_quantidade(i) > 0:
                        if (seleciona_inventario(pedidos_pendentes_pi(i)) > 1):
                                
                            if ordem_por_iniciar(i) == True:
                                ordem_a_processar(i)
                                hora_inicio_ordem(i)
                              
                            if get_valor("sAT1") == False and get_valor("sC2T1") == False:
                                  
                                #-----COLOCAR PECA NO TAPETE-----
                                set_valor_uint("ID_PECA_WO.peca_i", separar_P(pedidos_pendentes_pi(i)))
                                        
                                #------ATUALIZAR BASE DE DADOS-------
                                saida_peca(pedidos_pendentes_pi(i))
                                atualizar_pecas_pendentes(i)
                                atualizar_pecas_em_processamento(i)
                                        
                                #------VERIFICAR SE HA NOVAS ORDENS-----
                                tamanho = nr_ordens_pendentes()
                                         
                                time.sleep(3)
                                set_valor_uint("ID_PECA_WO.peca_i", 0)
                                 
                                if get_valor("sC7T3") == True or get_valor("sC7T4") == True or get_valor("sC7T5") == True:
                                    
                                    atualizar_pecas_processadas(i)
                                    atualizar_pecas_em_processamento_fim(i)
                                    #-----NESTE MOMENTO A PECA ESTA CONSIDERADA PROCESSADA QUANDO CHEGA AO INICIO DOS PUSHERS ---- A ALTERAR!
                                    entrada_peca(pedidos_pendentes_pf(i))
                                    
                            #----ESTE DELAY PERMITE A ENTRADA CORRETA DE PECAS NO ARMAZEM---  
                            
                                  
                        else:
                            ordem_suspenso(i)
                            break   
                          
                     
                            
                         
                    if get_valor("sC7T3") == True or get_valor("sC7T4") == True or get_valor("sC7T5") == True:
                                    
                        atualizar_pecas_processadas(i)
                        atualizar_pecas_em_processamento_fim(i)
                        #-----NESTE MOMENTO A PECA ESTA CONSIDERADA PROCESSADA QUANDO ECHEGA AO INICIO DOS PUSHERS ---- A ALTERAR!
                        entrada_peca(pedidos_pendentes_pf(i))
                                
                     
                             
                hora_fim_ordem(i)
                ordem_processada(i)
                          
                         
            i = i + 1
            
            
def separar_P(peca):
    return int(peca.split('P')[1])


def int_maquina(maquina):
    if maquina == 'Ma':
        return 1
    if maquina == 'Mb':
        return 2
    if maquina == 'Mc':
        return 3
    return 0

main()