import psycopg2
import functools 
from datetime import datetime

class Base_Dados():
    
    connection= psycopg2.connect(host="db.fe.up.pt", database="up201603858", user="up201603858", password="onr482mNS", port="5432")

    connection.autocommit= True
    cursor = connection.cursor()
    
    connection.commit()
    
    uid=1

#Insere uma ordem na basedados 
def basedados_inserir_ordem(numero_de_ordem, tipo_de_ordem, quantidade, peca_inicial, peca_final, destino, hora_entrada_ordem,hora_inicio_ordem, hora_fim_ordem):
    #conta o numero de linhas da tabela
    Base_Dados.cursor.execute("SELECT COUNT (*) FROM pedidos_pendentes")  
    n_pedidos_pendentes = 1+Base_Dados.cursor.fetchone()[0]
    
    #na tabela de Ordens
    sql_insert_query = ("""INSERT INTO "ordens" ("id", "ordem_id","tipo","estado","pecas_processadas","pecas_em_processamento","pecas_pendentes","peca_inicial", "peca_final", "destino", "hora_entrada_ordem", "hora_inicio_ordem", "hora_fim_ordem") VALUES (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s, %s, %s)""")
    insert_tuple = (n_pedidos_pendentes, numero_de_ordem , tipo_de_ordem, 'pendente','0', '0', quantidade, peca_inicial, peca_final, destino, hora_entrada_ordem, hora_inicio_ordem, hora_fim_ordem)
    Base_Dados.cursor.execute(sql_insert_query, insert_tuple)

    #na tabela de pedidos_pendentes
    sql_insert_query2 = ("""INSERT INTO "pedidos_pendentes" ("id", "order_id","peca_inicial", "peca_final", "quantidade_desejada", "destino", "tipo", "hora_entrada_ordem") VALUES (%s,%s,%s,%s,%s,%s,%s, %s)""")
    insert_tuple2 =(n_pedidos_pendentes, numero_de_ordem, peca_inicial, peca_final, quantidade, destino, tipo_de_ordem, hora_entrada_ordem )
    Base_Dados.cursor.execute(sql_insert_query2, insert_tuple2)

    return

def reinicia_armazem():
    
    sql_insert_query = ("""Update "inventario" set "p1" = 54 , "p2" = 54, "p3"=54, "p4"=54, "p5"=54, "p6"=54, "p7"=54, "p8"=54, "p9"=54  where "id" = 1""")
    
    Base_Dados.cursor.execute(sql_insert_query)

    return 

def pedidos_pendentes_tipo(i):
    
    PostgreSQL_select_Query = "select tipo from pedidos_pendentes WHERE id=" + str(i)
    Base_Dados.cursor.execute(PostgreSQL_select_Query)
    Proxima_ordem_tipo = Base_Dados.cursor.fetchone()
    Proxima_ordem_tipo =  ''.join(Proxima_ordem_tipo) #a fun��o retorna um TUPLE. Com ''.join() � tranformado em STRING
    return Proxima_ordem_tipo


def pecas_pendentes_quantidade(i):
    PostgreSQL_select_Query = "select pecas_pendentes from ordens WHERE id=" + str(i)
    Base_Dados.cursor.execute(PostgreSQL_select_Query)
    Proxima_ordem_quantidade = Base_Dados.cursor.fetchone()
    Proxima_ordem_quantidade = functools.reduce(lambda sub, ele: sub * 10 + ele, Proxima_ordem_quantidade) 
    return int(Proxima_ordem_quantidade)

def quantidade_desejada(i):
    PostgreSQL_select_Query = "select quantidade_desejada from pedidos_pendentes WHERE id=" + str(i)
    Base_Dados.cursor.execute(PostgreSQL_select_Query)
    Proxima_ordem_quantidade = Base_Dados.cursor.fetchone()
    Proxima_ordem_quantidade = functools.reduce(lambda sub, ele: sub * 10 + ele, Proxima_ordem_quantidade) 
    return Proxima_ordem_quantidade

def pedidos_pendentes_pi(i):
    PostgreSQL_select_Query = "select peca_inicial from pedidos_pendentes WHERE id=" + str(i)
    Base_Dados.cursor.execute(PostgreSQL_select_Query)
    Proxima_ordem_pi = Base_Dados.cursor.fetchone()
    Proxima_ordem_pi =  ''.join(Proxima_ordem_pi)
    return Proxima_ordem_pi


def pedidos_pendentes_pf(i):
    PostgreSQL_select_Query = "select peca_final from pedidos_pendentes WHERE id=" + str(i)
    Base_Dados.cursor.execute(PostgreSQL_select_Query)
    Proxima_ordem_pf = Base_Dados.cursor.fetchone()
    Proxima_ordem_pf =  ''.join(Proxima_ordem_pf)
    return Proxima_ordem_pf
    
    
def apagar_ordem_executada():
    deleteStatement = "DELETE FROM pedidos_pendentes WHERE id= (SELECT id FROM pedidos_pendentes order by id limit 1)"
    Base_Dados.cursor.execute(deleteStatement)
    
    
def nr_ordens_pendentes():
    query = "SELECT COUNT (*) FROM pedidos_pendentes"
    Base_Dados.cursor.execute(query)
    result = Base_Dados.cursor.fetchone()
    return result[0]
 
    
def seleciona_processo(pi, pf):
    query = "SELECT id from processo WHERE pi='" + pi + "' AND pf='" + pf + "'"
    Base_Dados.cursor.execute(query)
    result = Base_Dados.cursor.fetchone()
    result = functools.reduce(lambda sub, ele: sub * 10 + ele, result)
    return result


def seleciona_inventario(pi):
    query = "SELECT " + pi + " FROM inventario WHERE id=1"
    Base_Dados.cursor.execute(query)
    result = Base_Dados.cursor.fetchone()
    result = functools.reduce(lambda sub, ele: sub * 10 + ele, result) 
    return result


def ordem_a_processar(i):
    query = "UPDATE ordens SET estado = 'a processar' WHERE id =" + str(i)
    Base_Dados.cursor.execute(query)
    

def ordem_processada(i):
    query = "UPDATE ordens SET estado = 'processada' WHERE id =" + str(i)
    Base_Dados.cursor.execute(query)
    

def ordem_suspenso(i):
    query = "UPDATE ordens SET estado = 'suspenso' WHERE id =" + str(i)
    Base_Dados.cursor.execute(query)


def hora_inicio_ordem(i):
    now = datetime.now()
    
    query = "UPDATE ordens SET hora_inicio_ordem = '" + str(now) + "' WHERE id =" + str(i)
    Base_Dados.cursor.execute(query)


def nr_pecas_processadas(i):
    query= "SELECT pecas_processadas FROM ordens WHERE id=" + str(i)
    Base_Dados.cursor.execute(query)
    result = Base_Dados.cursor.fetchone()
    result = functools.reduce(lambda sub, ele: sub * 10 + ele, result)
    return int(result)
    
    
def ordem_por_iniciar(i):
    query1 = "SELECT pecas_em_processamento FROM ordens WHERE id=" + str(i)
    query2 = "SELECT pecas_processadas FROM ordens WHERE id=" + str(i)
    
    #---BUSCAR N�MERO DE PECAS EM PROCESSAMENTO-----
    Base_Dados.cursor.execute(query1)
    result1 = Base_Dados.cursor.fetchone()
    result1 = functools.reduce(lambda sub, ele: sub * 10 + ele, result1)
    
    #---BUSCAR N�MERO DE PECAS PROCESSADAS-----
    Base_Dados.cursor.execute(query2)
    result2 = Base_Dados.cursor.fetchone()
    result2 = functools.reduce(lambda sub, ele: sub * 10 + ele, result2)
    
    #-----EST� POR INICIAR SE AMBOS CONTADORES ESTIVEREM A 0-----
    if result1 == 0 and result2 == 0:
        return True
    else:
        return False
 
   
def hora_fim_ordem(i):
    now = datetime.now()
    
    query = "UPDATE ordens SET hora_fim_ordem = '" + str(now) + "' WHERE id =" + str(i)
    Base_Dados.cursor.execute(query)
    
        
def ferramenta1(id_processo):
    query = "SELECT ferramenta1 FROM processo WHERE id=" + str(id_processo)
    Base_Dados.cursor.execute(query)
    f1 = Base_Dados.cursor.fetchone()
    f1 = functools.reduce(lambda sub, ele: sub * 10 + ele, f1)  
    return f1

def ferramenta2(id_processo):
    
    query = "SELECT ferramenta2 FROM processo WHERE id=" + str(id_processo)
    Base_Dados.cursor.execute(query)
    f2 = Base_Dados.cursor.fetchone()
    f2 = functools.reduce(lambda sub, ele: sub * 10 + ele, f2) 
    return f2 
     
def ferramenta3(id_processo):
        
    query = "SELECT ferramenta3 FROM processo WHERE id=" + str(id_processo)
    Base_Dados.cursor.execute(query)
    f3 = Base_Dados.cursor.fetchone()
    f3 = functools.reduce(lambda sub, ele: sub * 10 + ele, f3) 
    return f3

def ferramenta4(id_processo):
    
    query = "SELECT ferramenta4 FROM processo WHERE id=" + str(id_processo)
    Base_Dados.cursor.execute(query)
    f4 = Base_Dados.cursor.fetchone()
    f4 = functools.reduce(lambda sub, ele: sub * 10 + ele, f4) 
    
    return f4  
        
def ferramenta5(id_processo):
       
    query = "SELECT ferramenta5 FROM processo WHERE id=" + str(id_processo)
    Base_Dados.cursor.execute(query)
    f5 = Base_Dados.cursor.fetchone()
    f5 = functools.reduce(lambda sub, ele: sub * 10 + ele, f5) 
   
    return f5


def maquina1(id_processo):
    query = "SELECT maquina1 FROM processo WHERE id=" + str(id_processo)
    Base_Dados.cursor.execute(query)
    m1 = Base_Dados.cursor.fetchone()
    m1 =  ''.join(m1)
    return m1

def maquina2(id_processo):
    query = "SELECT maquina2 FROM processo WHERE id=" + str(id_processo)
    Base_Dados.cursor.execute(query)
    m2 = Base_Dados.cursor.fetchone()
    m2 =  ''.join(m2)
    return m2

def maquina3(id_processo):
    query = "SELECT maquina3 FROM processo WHERE id=" + str(id_processo)
    Base_Dados.cursor.execute(query)
    m3 = Base_Dados.cursor.fetchone()
    m3 =  ''.join(m3)
    return m3

def maquina4(id_processo):
    query = "SELECT maquina4 FROM processo WHERE id=" + str(id_processo)
    Base_Dados.cursor.execute(query)
    m4 = Base_Dados.cursor.fetchone()
    m4 =  ''.join(m4)
    return m4

def maquina5(id_processo):
    query = "SELECT maquina4 FROM processo WHERE id=" + str(id_processo)
    Base_Dados.cursor.execute(query)
    m5 = Base_Dados.cursor.fetchone()
    m5 =  ''.join(m5)
    return m5

def tempo1(id_processo):
    query = "SELECT tempo1 FROM processo WHERE id=" + str(id_processo)
    Base_Dados.cursor.execute(query)
    t1 = Base_Dados.cursor.fetchone()
    t1 = functools.reduce(lambda sub, ele: sub * 10 + ele, t1) 
    return t1

def tempo2(id_processo):
    query = "SELECT tempo2 FROM processo WHERE id=" + str(id_processo)
    Base_Dados.cursor.execute(query)
    t2 = Base_Dados.cursor.fetchone()
    t2 = functools.reduce(lambda sub, ele: sub * 10 + ele, t2) 
    return t2

def tempo3(id_processo):
    query = "SELECT tempo3 FROM processo WHERE id=" + str(id_processo)
    Base_Dados.cursor.execute(query)
    t3 = Base_Dados.cursor.fetchone()
    t3 = functools.reduce(lambda sub, ele: sub * 10 + ele, t3) 
    return t3

def tempo4(id_processo):
    query = "SELECT tempo4 FROM processo WHERE id=" + str(id_processo)
    Base_Dados.cursor.execute(query)
    t4 = Base_Dados.cursor.fetchone()
    t4 = functools.reduce(lambda sub, ele: sub * 10 + ele, t4) 
    return t4

def tempo5(id_processo):
    query = "SELECT tempo5 FROM processo WHERE id=" + str(id_processo)
    Base_Dados.cursor.execute(query)
    t5 = Base_Dados.cursor.fetchone()
    t5 = functools.reduce(lambda sub, ele: sub * 10 + ele, t5) 
    return t5

def atualizar_pecas_pendentes(i):
    query1 = "SELECT pecas_pendentes FROM ordens WHERE id=" + str(i)
    Base_Dados.cursor.execute(query1)
    quant = Base_Dados.cursor.fetchone()
    quant = functools.reduce(lambda sub, ele: sub * 10 + ele, quant) - 1
    
    query2 = "UPDATE ordens SET pecas_pendentes = " + str(quant) + "WHERE id =" + str(i)
    Base_Dados.cursor.execute(query2)
    
    
def atualizar_pecas_em_processamento(i):
    query1 = "SELECT pecas_em_processamento FROM ordens WHERE id=" + str(i)
    Base_Dados.cursor.execute(query1)
    quant = Base_Dados.cursor.fetchone()
    quant = functools.reduce(lambda sub, ele: sub * 10 + ele, quant) + 1
    
    query2 = "UPDATE ordens SET pecas_em_processamento = " + str(quant) + "WHERE id =" + str(i)
    Base_Dados.cursor.execute(query2)


def atualizar_pecas_em_processamento_fim(i):
    query1 = "SELECT pecas_em_processamento FROM ordens WHERE id=" + str(i)
    Base_Dados.cursor.execute(query1)
    quant = Base_Dados.cursor.fetchone()
    quant = functools.reduce(lambda sub, ele: sub * 10 + ele, quant) - 1
    
    query2 = "UPDATE ordens SET pecas_em_processamento = " + str(quant) + "WHERE id =" + str(i)
    Base_Dados.cursor.execute(query2)

def atualizar_pecas_processadas(i):
    query1 = "SELECT pecas_processadas FROM ordens WHERE id=" + str(i)
    Base_Dados.cursor.execute(query1)
    quant = Base_Dados.cursor.fetchone()
    quant = functools.reduce(lambda sub, ele: sub * 10 + ele, quant) + 1
    
    query2 = "UPDATE ordens SET pecas_processadas = " + str(quant) + "WHERE id =" + str(i)
    Base_Dados.cursor.execute(query2)
    
    
    
def saida_peca(pi):
    query = "SELECT " + pi + " FROM inventario WHERE id=1"
    Base_Dados.cursor.execute(query)
    result = Base_Dados.cursor.fetchone()
    result = functools.reduce(lambda sub, ele: sub * 10 + ele, result) 
    
    query2 = "UPDATE inventario SET " + pi + "=" + str(result-1) + " WHERE id = 1"
    Base_Dados.cursor.execute(query2)
    
    
def entrada_peca(pf):
    query = "SELECT " + pf + " FROM inventario WHERE id=1"
    Base_Dados.cursor.execute(query)
    result = Base_Dados.cursor.fetchone()
    result = functools.reduce(lambda sub, ele: sub * 10 + ele, result) + 1
    
    query2 = "UPDATE inventario SET " + pf + "=" + str(result) + " WHERE id = 1"
    Base_Dados.cursor.execute(query2)