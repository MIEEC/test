from client import * 
from basedados import *



while True:
    i=0
    for i in range(1, 10):
        aux = 0
        for j in range(1, 10):
            if i == 1:
                string = "C1T3.p_transf.P" + str(j)
            if i == 2:
                string = "C1T4.p_transf.P" + str(j)
            if i == 3:
                string = "C1T5.p_transf.P" + str(j)
            if i == 4:
                string = "C3T3.p_transf.P" + str(j)
            if i == 5:
                string = "C3T4.p_transf.P" + str(j)
            if i == 6:
                string = "C3T5.p_transf.P" + str(j)
            if i == 7:
                string = "C5T3.p_transf.P" + str(j)
            if i == 8:
                string = "C5T4.p_transf.P" + str(j)
            if i == 9:
                string = "C5T5.p_transf.P" + str(j)
                  
            result = get_valor(string)
            aux += result
              
            atualizar_stats_maquina_db(j, i, result, aux)
            

