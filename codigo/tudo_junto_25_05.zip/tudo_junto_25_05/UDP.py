import xml.etree.ElementTree as ET
from getOrder import *
import psycopg2
import datetime
import socket
import time
import threading
import sys

UDP_IP_ADDRESS = "127.0.0.1"
UDP_PORT_NO = 1237


def create_socket():
    global UDP_PORT_NO
    global UDP_IP_ADDRESS
    global serverSock
    UDP_IP_ADDRESS = "127.0.0.1"
    UDP_PORT_NO = 1237
    serverSock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    serverSock.bind((UDP_IP_ADDRESS, UDP_PORT_NO))
    print("A espera de receber ficheiros na porta:" +str(UDP_PORT_NO))

def receber_ficheiros():
    data = serverSock.recv(8192)
    data = data.decode()
    xml = str(data)
    print("Ficheiro recebido")
    #print(xml)
    receber_ordem(xml)